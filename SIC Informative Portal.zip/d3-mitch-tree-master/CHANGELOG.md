## [1.1.1](https://github.com/deltoss/d3-mitch-tree/compare/v1.1.0...v1.1.1) (2020-01-08)

# [1.1.0](https://github.com/deltoss/d3-mitch-tree/compare/v1.0.7...v1.1.0) (2019-12-07)


### Bug Fixes

* 🐛 Adjusted CSS that disables clicking on the node body ([47f1491](https://github.com/deltoss/d3-mitch-tree/commit/47f1491ba296a84130a5f4edde69fecca060f1d6))
* 🐛 Adjusted node exit animations for circle/boxed tree ([7bddc45](https://github.com/deltoss/d3-mitch-tree/commit/7bddc45b2869c2cfa5c20834e07449b7c2a02af6))
* 🐛 Fixed broken x/y animation for texts for exiting nodes ([04f4872](https://github.com/deltoss/d3-mitch-tree/commit/04f487230d4ea3b6078760edc3aa6501f299c0b9))


### Features

* 🎸 Added auto-prefixer for SASS. Adjusted SASS for firefox ([ab8dd33](https://github.com/deltoss/d3-mitch-tree/commit/ab8dd33fcc3cab8460967a43397a3c7096ed375d))
