import BoxedTree from './js/BoxedTree';
import CircleTree from './js/CircleTree';

export default {
    boxedTree: BoxedTree,
    circleTree: CircleTree
};